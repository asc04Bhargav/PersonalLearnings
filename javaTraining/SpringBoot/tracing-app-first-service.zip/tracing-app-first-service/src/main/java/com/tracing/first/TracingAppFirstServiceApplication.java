package com.tracing.first;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TracingAppFirstServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(TracingAppFirstServiceApplication.class, args);
	}

}
