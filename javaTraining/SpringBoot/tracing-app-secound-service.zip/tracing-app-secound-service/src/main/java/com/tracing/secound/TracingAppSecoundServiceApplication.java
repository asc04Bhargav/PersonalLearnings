package com.tracing.secound;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TracingAppSecoundServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(TracingAppSecoundServiceApplication.class, args);
	}

}
