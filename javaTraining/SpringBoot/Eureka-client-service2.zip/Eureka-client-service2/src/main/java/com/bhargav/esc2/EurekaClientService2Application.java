package com.bhargav.esc2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EurekaClientService2Application {

	public static void main(String[] args) {
		SpringApplication.run(EurekaClientService2Application.class, args);
	}

}
