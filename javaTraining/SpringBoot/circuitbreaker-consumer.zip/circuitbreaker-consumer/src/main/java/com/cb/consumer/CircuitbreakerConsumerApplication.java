package com.cb.consumer;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CircuitbreakerConsumerApplication {

	public static void main(String[] args) {
		SpringApplication.run(CircuitbreakerConsumerApplication.class, args);
	}

}
