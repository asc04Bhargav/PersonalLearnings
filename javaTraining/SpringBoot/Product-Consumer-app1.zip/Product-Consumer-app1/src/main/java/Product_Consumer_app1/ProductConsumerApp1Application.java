package Product_Consumer_app1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProductConsumerApp1Application {

	public static void main(String[] args) {
		SpringApplication.run(ProductConsumerApp1Application.class, args);
	}

}
