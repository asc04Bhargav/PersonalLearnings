package com.spring.data.jpa.ex1;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class ProductService {

    @Autowired
    private ProductRepository repo;

    public void addOrUpdateProduct(Product p){
        repo.save(p);  //this will internally
        System.out.println("Record added or updated..");
    }


}
