package com.spring.data.jpa.ex1;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class ProductMain1 {
    public static void main(String[] args) {
        ApplicationContext ctx = new AnnotationConfigApplicationContext(JpaConfig1.class);
        ProductService ps = ctx.getBean(ProductService.class);
        ps.addOrUpdateProduct(new Product(101,"Product-101",110,"category-a"));
    }
}
