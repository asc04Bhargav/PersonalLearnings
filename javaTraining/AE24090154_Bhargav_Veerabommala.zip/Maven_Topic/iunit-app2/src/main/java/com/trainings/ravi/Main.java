package com.trainings.ravi;

public class Main {
    public static void main(String[] args) {

        System.out.println("Hello world!");
    }
}