public interface ExtendedShape {
}
