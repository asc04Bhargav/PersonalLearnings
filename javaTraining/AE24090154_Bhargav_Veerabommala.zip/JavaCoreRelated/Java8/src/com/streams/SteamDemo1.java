package com.streams;

import java.util.stream.IntStream;
import java.util.stream.Stream;

public class SteamDemo1 {
    public static void main(String[] args) {
//        Stream<Integer> s1 = Stream.of(34,56,8,12,67,78);
//
//        s1.forEach(i -> System.out.println(i));

//        IntStream.range(21,30).min().ifPresent(i-> System.out.println(i));

        IntStream is1 = IntStream.of(56,12,67,89,1,0,23,45);
        is1.sorted().forEach(System.out::println);

        System.out.println();
        is1 =IntStream.of(56,12,67,89,1,0,23,45);
        is1.map(i -> i*10)
                .filter(i -> i>35)
                .forEach(System.out::println);

        Stream<String> s2 = Stream.of("java","Python","React");
        s2.forEach(System.out::println);


    }
}
