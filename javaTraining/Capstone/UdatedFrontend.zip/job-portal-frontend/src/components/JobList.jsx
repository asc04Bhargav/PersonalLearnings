import { Link, useNavigate } from 'react-router-dom'
import { deleteJob } from '../services/api'

function JobList({ jobs, reloadJobs }) {
  const navigate = useNavigate()

  const handleDelete = async (id) => {
    if (confirm('Are you sure you want to delete this job?')) {
      await deleteJob(id)
      alert('Job deleted successfully')
      reloadJobs()
    }
  }

  if (jobs.length === 0) {
    return <p>No jobs found.</p>
  }

  return (
    <div>
      <h2>Available Jobs</h2>
      {jobs.map(job => (
        <div key={job.id} style={{ border: '1px solid #ccc', padding: '10px', marginBottom: '10px' }}>
          <h3>{job.title} @ {job.companyName}</h3>
          <p><strong>Location:</strong> {job.location}</p>
          <p><strong>Salary:</strong> {job.salary}</p>
          <p>{job.description.substring(0, 100)}...</p>

          <Link to={`/apply/${job.id}`}>Apply</Link> |{' '}
          <button onClick={() => navigate(`/edit-job/${job.id}`)}>Edit</button> |{' '}
          <button onClick={() => handleDelete(job.id)}>Delete</button>
        </div>
      ))}
    </div>
  )
}

export default JobList
