import { useParams, useNavigate } from 'react-router-dom'
import { useState, useEffect } from 'react'
import { fetchJobById, createJob, updateJob } from '../services/api'

function JobForm() {
  const { jobId } = useParams()
  const navigate = useNavigate()

  const [form, setForm] = useState({
    title: '',
    description: '',
    location: '',
    companyName: '',
    salary: '',
    skills: ''
  })

  const isEditing = Boolean(jobId)

  useEffect(() => {
    if (isEditing) {
      const loadJob = async () => {
        const data = await fetchJobById(jobId)
        setForm({
          title: data.title,
          description: data.description,
          location: data.location,
          companyName: data.companyName,
          salary: data.salary,
          skills: data.skills
        })
      }
      loadJob()
    }
  }, [jobId])

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value })
  }

  const handleSubmit = async (e) => {
    e.preventDefault()
    if (isEditing) {
      await updateJob(jobId, form)
      alert('Job updated successfully!')
    } else {
      await createJob(form)
      alert('Job created successfully!')
    }
    navigate('/')
  }

  return (
    <div>
      <h2>{isEditing ? 'Edit Job' : 'Add New Job'}</h2>

      <form onSubmit={handleSubmit}>
        <input
          type="text"
          name="title"
          placeholder="Job Title"
          value={form.title}
          onChange={handleChange}
          required
        />
        <textarea
          name="description"
          placeholder="Job Description"
          value={form.description}
          onChange={handleChange}
          required
        ></textarea>
        <input
          type="text"
          name="location"
          placeholder="Location"
          value={form.location}
          onChange={handleChange}
          required
        />
        <input
          type="text"
          name="companyName"
          placeholder="Company Name"
          value={form.companyName}
          onChange={handleChange}
          required
        />
        <input
          type="number"
          name="salary"
          placeholder="Salary"
          value={form.salary}
          onChange={handleChange}
          required
        />
        <textarea
          name="skills"
          placeholder="Required Skills (comma-separated)"
          value={form.skills}
          onChange={handleChange}
          required
        ></textarea>

        <button type="submit">{isEditing ? 'Update Job' : 'Create Job'}</button>
      </form>
    </div>
  )
}

export default JobForm
