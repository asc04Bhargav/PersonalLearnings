import { useParams, useNavigate } from 'react-router-dom'
import { useState, useEffect } from 'react'
import { fetchJobById, applyForJob } from '../services/api'

function ApplicationForm() {
  const { jobId } = useParams()
  const navigate = useNavigate()

  const [job, setJob] = useState(null)
  const [form, setForm] = useState({
    jobId: jobId,
    fullName: '',
    email: '',
    phone: '',
    skills: ''
  })

  useEffect(() => {
    const loadJob = async () => {
      const data = await fetchJobById(jobId)
      setJob(data)
    }
    loadJob()
  }, [jobId])

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value })
  }

  const handleSubmit = async (e) => {
    e.preventDefault()
    await applyForJob(form)
    alert('Application submitted successfully!')
    navigate('/')
  }

  if (!job) return <p>Loading job details...</p>

  return (
    <div>
      <h2>Apply for: {job.title} @ {job.companyName}</h2>

      <form onSubmit={handleSubmit}>
        <input
          type="text"
          name="fullName"
          placeholder="Full Name"
          value={form.fullName}
          onChange={handleChange}
          required
        />
        <input
          type="email"
          name="email"
          placeholder="Email"
          value={form.email}
          onChange={handleChange}
          required
        />
        <input
          type="tel"
          name="phone"
          placeholder="Phone"
          value={form.phone}
          onChange={handleChange}
          required
        />
        <textarea
          name="skills"
          placeholder="Your Skills (comma-separated)"
          value={form.skills}
          onChange={handleChange}
          required
        ></textarea>

        <button type="submit">Submit Application</button>
      </form>
    </div>
  )
}

export default ApplicationForm
