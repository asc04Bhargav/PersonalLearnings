import { useState, useEffect } from 'react'
import JobList from '../components/JobList'
import { fetchJobs } from '../services/api'

function Home() {
  const [jobs, setJobs] = useState([])
  const [searchTerm, setSearchTerm] = useState('')

  useEffect(() => {
    loadJobs()
  }, [])

  const loadJobs = async () => {
    const data = await fetchJobs()
    setJobs(data)
  }

  const handleSearch = (e) => {
    e.preventDefault()
    const filtered = jobs.filter(job =>
      job.title.toLowerCase().includes(searchTerm.toLowerCase())
    )
    setJobs(filtered)
  }

  return (
    <div>
      <h1>Job Board Lite</h1>
      <p>Find and apply for your dream job!</p>

      <form onSubmit={handleSearch}>
        <input
          type="text"
          placeholder="Search by role"
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
        />
        <button type="submit">Search</button>
        <button type="button" onClick={loadJobs} style={{ marginLeft: '10px' }}>Reset</button>
      </form>

      <JobList jobs={jobs} reloadJobs={loadJobs} />
    </div>
  )
}

export default Home
