package com.bhargav.BankAccount_RestApi1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BankAccountRestApi1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
