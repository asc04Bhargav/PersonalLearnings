package com.bhargav.BankAccount_RestApi1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BankAccountRestApi1Application {

	public static void main(String[] args) {
		SpringApplication.run(BankAccountRestApi1Application.class, args);
	}

}
